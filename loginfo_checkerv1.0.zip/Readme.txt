/**
*
 * =============================================================
 *  LOGIN INFO CHECKER (LIC) v.01 (a.k.a Login Cracker)
 *  by 
 *  2008 , Aung Khant
 *  http://yehg.net, YGN Ethical Hacker Group, Yangon, Myanmar
 * 
 *  For forcing admins/users to select strong passwords.
 *  You can add more stronger stricer logic.
 * =============================================================
 *
 * @compatibility php4, php5 >=
 *
 * @usage		loginfo_checker($_REQUEST['username'],$_REQUEST['password']);
 *  
 * @test		Go to URL:  loginfo_checker.php?testlic
 * @notice 		BadChoicesOfUsername&Password.txt is needed to exist at the same directory of loginfo_checker.php.
 *
 */


View Live Demonstration
http://yehg.net/lab/pr0js/files.php/phploginfo_checker_demo.zip
