<?php
/**
 *
 * ===========================================================================
 *  LOGIN INFO CHECKER (LIC) v.01
 *  by 
 *  � 2008 , d0ubl3_h3lix 
 *  http://yehg.org, YGN Ethical Hacker Group, Yangon, Myanmar
 * 
 *  For forcing admins/users to select strong passwords.
 *  You can add more stronger stricer logic.
 * ===========================================================================
 *
 * @compatibility php4, php5 >=
 *
 * @usage		loginfo_checker($_REQUEST['username'],$_REQUEST['password']);
 *  
 * @test		just append ?test like loginfo_checker.php?testlic
 *
 * @notice 	BadChoicesOfUsername&Password.txt is needed to exist at the same directory of loginfo_checker.php 
 *
 */

error_reporting(0);

function loginfo_checker($username,$password)
{
//@step 1. Dictionary Enumeration - including Hacker terms

$bads = file_get_contents("BadChoicesOfUsername&Password.txt");
$arb = explode("\n",$bads);

$username = trim($username);
$password = trim($password);

foreach($arb as $r)
{
	$r = trim($r);
	//echo 'Testing .. '.$r.'<br>';
	if ($username === $r)
	{
		issue_warn("Your name \"$username\" is exposed to brute-force and guessable attacks","Choose non-dictionary and non-doer word (eg. don't choose manager.)");
	}
	if ($password === $r)
	{
		issue_warn("Your password \"$password\" is exposed to brute-force and guessable attacks","Choose non-dictionary and non-doer word (eg. don't choose manager.)");
	}
	// Also test in hacker terms
	if ($username === hackerspeak($r,'light') )
	{
		issue_warn("Your name \"$username\" is exposed to brute-force and guessable attacks","Choose non-hackerspeak word (eg. don't choose h4110)");
	}
	if ($password === hackerspeak($r,'light') )
	{
		issue_warn("Your password \"$password\" is exposed to brute-force and guessable attacks","Choose non-hackerspeak word (eg. don't choose h4110)");
	}
		
	if ($username === hackerspeak($r) )
	{
		issue_warn("Your name \"$username\" is exposed to brute-force and guessable attacks","Choose non-hackerspeak word (eg. don't choose h4110)");
	}
	if ($password === hackerspeak($r) )
	{
		issue_warn("Your password \"$password\" is exposed to brute-force and guessable attacks","Choose non-hackerspeak word (eg. don't choose h4110)");
	}
	
	$r = preg_quote(r);
	if (preg_match("/$r/i",$username))
	{
	     issue_warn("Portions of username are guessable.","Your username should not contain dictionary word");
	}
	if (preg_match("/$r/i",$password))
	{
		issue_warn("Portions of password are guessable.","Your password should not contain dictionary word");	
	}
	
		
}
//@step 2. Portion of username/password in each
$tmpu = preg_quote($username);
$tmpp= preg_quote($password);



if (preg_match("/$tmpp/i",$username))
{
        issue_warn("Portions of password in username; vice versa","Your username should be unique to password and should not contain your password characters");
}
if (preg_match("/$tmpu/i",$password))
{
        issue_warn("Portions of username in password; vice versa","Your password should be unique to username and should not contain your username characters");
}

//@step 3. Numbers,Characters,Special Characters

$is_digit_include = (preg_match("/\d/i", $password));
$is_char_include = (preg_match("/\S/i", $password));
$is_nonword_include = (preg_match("/\W/i", $password));
if ( (!$is_char_include) OR (!$is_digit_include) OR (!$is_nonword_include))
{
  issue_warn("Weak Password Choice","Password must contain both alphanumerics and (special) characters"); 	
}
           

//@step 4. MD5 Crack usig gdataonline.com
md5_crack($password);
	 
}

function md5_crack($password)
{
	//@depends GDataOnline.com which is the most reliable as far as I tested 
	
	$html = file_get_contents("http://gdataonline.com/qkhash.php?mode=xml&hash=".md5($password));

	preg_match('@(<result>)+(\S+)+(?:</result>)+@i',
    $html, $matches);
	$plain = $matches[2];	
	if (strlen($plain)>0)
	{
		issue_warn("Your password \"$password\" has been found in online cracking database","Choose unusual strong password again");
	}	
	
}

function hackerspeak($str,$version='heavy')
{
   if ($version=='light')
   {
	   $plain = array('a','A',
	   				  'e','E',
					  'g','G',
					  'i','I',
					  'o','O',
					  't','T',
					  );
					  
	   $hackspeak = array('4','4',
	                   '3','3',
					   '9','9',
					   '1','1',
					   '0','0',
					   '7','7',
					   );		
   }	
   else {
	   $plain = array('a','A',
	   				  'e','E',
					  'g','G',
					  'i','I',
					  'o','O',
					  't','T',
					  'w','W',
					  'M','M');
					  
	   $hackspeak = array('4','4',
	                   '3','3',
					   '9','9',
					   '1','1',
					   '0','0',
					   '7','7',
					   '\\/\\/','\\/\\/',
					   '/\\/\\','/\\/\\'
					   );	
    }

   
   				   
   return str_replace($plain,$hackspeak,$str);
}

function issue_warn($reason,$remedy)
{
	$warnstyle = 'style="font-weight:bold;color:red;"';
	$greenstyle = 'style="font-weight:bold;color:green;"';
	$msg = "Reason: <span $warnstyle>$reason.</span><br /><br />Remedy: <span $greenstyle>$remedy.</span><br /><br />Please <a href=\"javascript:history.go(-1)\">go back</a> to re-enter again.";
	sec_warn($msg);
}		
function sec_warn($msg)
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Security Warning | Bad Account Credential Choice!</title>
</head>
<style type="text/css">
html{font-family:Georgia;}
</style>
<body>
<br />

<h1 style="text-align:center;border:outset 2px red;background-color:red;color:black;">Security Warning! </h1>
<div style="color:red;font-weight:bold;font-size:2em"><?=$msg?></div>
<br />
</p>
 <h1 style="text-align:center;border:outset 2px red;background-color:red;color:black;">Security Warning!</h1>
 <div style="font-style:italic;text-align:center;font-size:13px;position:relative;top:3%"> 
 LoginfoChecker &copy; d0ubl3_h3lix<br /><a href="http://yehg.org" target="_blank">http://yehg.org</a>
 <br />
 YGN Ethical Hacker Group (YEHG)
 <br />
 Yangon, Myanmar
 
 </div> 
</div>
</body>
</html>
<?
die();
}
if (isset($_REQUEST['testlic']))
{
	if (isset($_REQUEST['username']) && isset($_REQUEST['password']))
	{		
		loginfo_checker($_REQUEST['username'],$_REQUEST['password']);
		echo '<h1 style="color:green">Good Credential!</h1>';
	}	
	else 
	{
		?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
	<meta name="author" content="">

	<title>LoginfoChecker : SmokeTest</title>
</head>

<body>
<h2>Member Registration:</h2>
<br />
<form action="<?=$_SERVER["PHP_INFO"]?>?testlic" method="GET" enctype="text/plain">

<table width="80%" cellpadding="0">
  <tr>
    <td width="9%">Username :</td>
    <td width="70%"><input name="username" type="text" size="50" /></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input name="password" type="text" size="50" /> </td>
  </tr>

  <tr>
    <td>&nbsp;</td>
    <td>
    <input type="hidden" name="testlic" value="" />
    <input name="submit" type="submit" value="Register to SmokeTest LoginfoChecker" /></td>
  </tr>
</table>
 <div style="font-style:italic;font-size:15px;position:relative;top:15%"> 
 <br /> LoginfoChecker &copy; d0ubl3_h3lix<br /><a href="http://yehg.org" target="_blank">http://yehg.org</a>
 <br />
 YGN Ethical Hacker Group (YEHG)
 <br />
 Yangon, Myanmar
 
 </div> 
</body>
</html>		
		
		<?			
	}

}

?>
