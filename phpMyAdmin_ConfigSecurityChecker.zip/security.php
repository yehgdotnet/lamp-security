<?php
/**
 * phpMyAdmin Configuration Security Checker script
 *
 * @todo		Need to be updated each time new security-related configurations are added
 			    //may be Access Control, Availability, Performance, Integrity  				  
 * @descrption 	Check user-defined values against pre-defined secure values. 100% hardcoded.
 * @depend	   	config/config.inc.php , NOT /config.inc.php
 * @category   	Setup
 * @package    	phpMyAdmin-setup
 * @date	    July 20, 2008
 * @author     	Aung Khant <aungkhant[at]yehg.net>, http://yehg.net/lab
 * @license	   	GPL
 *
 * Just idea. May not be good codes. Please feel free to modify. 
 */
error_reporting(E_ALL);



$config_file = (file_exists("../config/config.inc.php"))?$config_file="../config/config.inc.php":die('<div style="color:red;font-weight:bold">You have not created a config file in config folder!</div>');		
require_once($config_file);		

$color_notice = '#FF557F';
$color_warning = 'red';
$color_neutral = '#00AAFF';
$no = 0;

function show_message($item,$msg,$color="")
{
	echo  '<li><span  style="font-size:1.2em;color:'.$color.';font-weight:bold;">'.$item.'</span> '.$msg.'</li>'."\n";	
	$GLOBALS['no']++;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta name="author" content="Aung Khant (http://yehg.net)">

	<title>phpMyAdmin Configuration Security Checker</title>
	<style type="text/css">
	body{
		font-family: Arial,Verdana,sans-serif;
		line-height: 2em;	
	}	
	
	#title{
		-moz-border-radius:3% 3% 0% 0%;
		padding:0% 2% 2% 2%;				
		text-align: center;		
		position:relative;
		font-size:1.5em;
		font-weight:bold;
	}

	</style>
</head>

<body>
<?
	
echo '<div id="title"><a href="http://phpmyadmin.net/" target="_blank"><img src="data:;base64,R0lGODlhrABkAOYAAPf39/f37/fv7/fv5u/v9+/v7/fv3u/v5vfm1vfmzu/m3vfmxebm7+bm5u/m1vfevffetebe3u/exfferebezt7e5t7e3vfWrffWpffWnO/Wtd7WztbW5tbW3tbW1s7W3vfOnO/OpffOlPfOjPfOhN7Otc7O3ubOlM7Ozs7Oxc7OvffFhPfFe/fFc+/FhObFnNbFvebFlN7FrdbFtd7FlNbFrcXF1tbFpf+9a73F1v+9Y/e9a/+9Wu+9c++9e969lN69jN69hNa9nL29zv+1Uv+1Sv+1Qve1Uua1a+a1c961e+a1Y+a1WrW1zv+tOv+tMfetQu+tUv+tKe+tSu+tQvetMf+lKfelMf+lGa2txf+lIfelKe+lOvelIaWlxf+cCKWlvf+cEP+cAPecGZycvZSUtYyMtYyMrYSErXuErXt7pXNzpXNznGtrnGNjnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAHAP8ALAAAAACsAGQAAAf/gACCg4SFhoeIiYqLjI2Oj4YNFpCUlZaXmJmajhYem5+goaKjigWdDaSpqqusiJINDQWts7S1mBYWsai2vL2YBbKFwMGLBR65ALG+y8yKDR4oKB67ptHSxK7HsgW7zd7NxtPPKLnQuZ2TiujBsN/uy9gN0R7Y2Ice2oLc9u/9tpL8SkmzQKydv4MIC8nLp49ewocHLQzEdgyixW8FouGKhyLgxY+VhgkDFkkjQUIZ04FcWSoSNI2yxs3DJpGcykHQurHcOchUPXywJOKTBuuZSmMmDQnlyRQAt5MoUeYU1tMarpIodDb9KAlqIpKJapLT6nTm1pW4vF56OfaexrMg/4/dtJTRKlkAbD3CfSfvaiaxWe+K9bT3oURJmtiKOyTP2t3C33I+dlR3nkFh1q5B9lf3siXAiw1Vfrv5XU3PldgSfay6Y2l30EJbamwVmdvMc1/3qiu7EmCbj3+71r2sZm9ISHHDCiicMPFeL49NXkS7NjfGmR0/51V54yXhG1Eny252Oy2x3kOStwnMIaHquM3TYptLr7P13qdhXj9cvqrR9VnSWjQAAdBJPfyR498q1aUHCXyOpZMSSglmtWAqqjn4iHAEqgQNMaOR59yFoIRYIHIJIiaIREdVaCGJoMCn4oMpqtRYMCGuZx+Mj7Q2Y4/8yVaXhC4qyGMmOf7YCP+E1ghpzTZF9ndkJRAqyQiHlun00iQ5rjfilJAMKJ5ACfYmFjBRvgjmIzketwiWWRKCXpde7rjmeyKOiQiddulUnUxFTncnIQO6mQiTyvmZ2TFpSjnoIV3mIiihLkpKIW4D8pfbo3iSZ+mSgSpT1aJwkjfpmpl+ykim2Z3YUHadpPklp/poqtahUboqSGuMpnnqkYhqmAirrd46YKxRukfrrpqKSmagtzZXKqzL1sqfrogQW6w9HCIbpZ0wIprVraI1ii2WgFZaLbHYKmVublgSpG1mv/rH57jFNEpPbuK2lyyt4uKrjr5WiutJNYFyqq2Vl8pqClbXChLwk4Peayj/To0SxW+FziWX4KbhcqzneBm7ObFO04K7nbYX45XxWGRN/KXHIq5572quvAwzxCm6FPGUE6tayLz4iTexZj5npyyM8wo9yNHrFcXzx4f+BrJ5N+8sDNFRG52mfabkxePRThuoM4FeR3n1e+jwOG1gWmWdYtrfPjKybnIvV8jbc/MDNWmOOCsf1Lr+zZ9PU7uoslP1wsW3rlwniPjeGa8dyYJyj1vQ2ZlNLufLjS/494k067wvP3w3aTlKwAQVOkipz5h6mQ+7GyQuRYHNTVf44IP74iuVHqSKmXNcO+W+SwrWnrvjopp0yz/39zTpRL5o79BvGr1ozXfCaoAJtfDF//jjOzHAITyQP74RASCSugxYkL+FNNinJelywIxAPvs9FdP9UCrYAvmSkCfg+aIIYkhgArGAAEMs4AsKTCAP9hQ5KETwCxLYXiJ0oMAJQqp1kugdf2oAwQQGYVGCe8gAnhDBBC7AEDxooRhYkLMieSAGMhTBIwJgBAWSYBhBEWGjgBDBG1jFgJTIAhrQQAZNJAALMsRAIR4YxWwpTS65OwALW6iDRgBDAVBM4Ausl6AkkG8MMCBKKwqgBje4oQyagIAMxbCCQnCwhV94IQACIIA+CiAZRTnAAQTQvkKMYI5PKGRP/geNG5TwCzWwRgomSclKVpI/MxCCJo1IED96Uv+Rn2AAG9yYBU2IYI4eFEQCwiBDLBhAEOkbXwsGYYAnkE+KhEBAGL/gBAVikHcvSYESqNCFMIwvgl1IYwDVx0xmdoEKQMgOFcJAzShMAgLN/EIYnqADCHziA250gw00gYM5GoEQLTBn+wKwRTGMYBBUFEMeC7EDBRohBCUUwwmzc4MtzFGBV4gGCf9JUCRYAwZdUGAPBHFIgooBl3tqQhYmSlEb6GQI4SRDRUE0BIpSdAha6WECn8BKMUjhfADQpQLDKAYPqlSe3hTEBFbqgKBYQAb5FEIKxqBAJmRHCCUlaBSi8QOH/vMLM4iGIxWIy3I69AmK6EA4p+oGNoxTEFn/oGo41VABQVSgDVp1QxuaMIgBWEGBLdBCAsOQAEE4VQxG6GUCSSCIB5QwDA2EhQ8Amh0uKJAK0bgCX60RwAiGoQtcuEI+CYgCJPhyDJDN5xcgG1QxRBMFREzgPAEgUjGEAQugzWcYFGGDsIbzA4Iog2nd0EQAgHO1V12lZjMgVzF4EwEl/YII2onLDChQCgJAShQUOFRrZFaeQogGExQYhqRGw7HEdW4KEprAH0RjuAksbgr8mUCDokAI+dwndMWAhfOZVYEZGMQp16qIJrixDWTwAhna6MYmFgANbkSDF7ygWjeaQRAYre9+6ftGQchxrQuIYQLTm84EFsGumtVj/4PFUARmcVcM3kXBdolr3AhedsMJDKg1buDLSKJAsAlcQjRmENTLDlSeRkQBdsXghD8uILcPGAQGFKgFRZDBjWp42hryCwBRupGsgsCvG/4LgB+7YQ2DYAB90yCL9ZJ3ABNewQBYOoGZLhClREDrilRAXX1aIwmGhewYKqtiFCzVhJk5bjJRgFAF7lMIJSYqc9N4YgV2EQAHJu8rBcECeypCyXAcxBmA7NpwXvW+9RWEGfxLgEFM2g1UBsBbodpQMeiABAp0AgAm7IR1tlOHyXjzF2I8A54aVQxUOAYONZvBYUwYCrgowSNjrAQFdkEF0UBziFNA5zLXEQCdTuQgwv+cQBwkggFDdkMp9UHf/wbYDV0FwFePXGT6ttYpSkZDpTtbYS+TV60L5qyfVbnLmBagqAkcA7Bl/OoFvrLTriSEgj0tiB0vkAKdWG4CuWCNGRf3zQ91awcHwU4FvhMRHQCrG4YwiIi70QsA8AKQGSAIEzha26N0A5K1LfEmCgDdYnB2PCP4hD6inK6ALmG+BbHXECs1n68OQQNcwFwKFCUCVVCgC2BR6ATWWBAITKBPA6tA757Al3qsLQ0FYQAuJ6K0bsx2k8NpAgD09wyVBoB7sw4Aj7ux64JwshtyAADZJvCdW5bhO1eOS3N/AQMGyPu+i0sFBY4hCD94QQi6fIH/eqK1ACCIoA4GXXWmcuMICjwCLBQgBR9yYwNlDgJBVrBS86I8vXW9a1sRMfY2DMEGQ1i0G88A7kgLQuNuUIMsAjxW1F/aDWiQhbkTHoDaJlAL5/O3Z/W4e21SM58GPS6GodIVCeSzwrg1LGhZ+oUGAkDq3JAAS0Mgi3h+QQOwDHX7bhxhHfMYpYdQu1bX0NUGSHzkl2ay+qnahg4wFOrhj+DDiy4G4FOdpf9kXRfWBQ7AOAFiACinBa80Yf/kfwjIVAbmSxkEAOZWXoLQTn9WgYMGAPxXYYmgZFqFBhwgCK8lToIgZa6nelqlBqglCHckaIQWQTPXWaI2CBmAc3hU/wLC9nbJYBuDkHQJ5E0B8IJz5IHep0dW5n8AwHlGdwANQAEsBXOgNlKEAITOhgjQBmRlYAZl4AU2QAwfYAZcuAsMsIVmME5spIViSAZDgA06oAVWoAVFUEgTYAV2qAUPFwBFAIdaMHXw1AJFYARSIAUspQUJAAVd0AVyqAA+SAgkAIdxiGqAhgNF8AR2eIl9WFd8aD4MxYc6UEgswIc7AAsSYIl2eAGExoeztGx8CHqHYHEmiAnbNnGKEADrhAigZIt7tAgCwGwUtkfcEAD7kAjtE1x2kou7SAi3yHCvQAygJAi6+IzRSFqnlQlmF4uqgAA4oAPc2I2Vp0CSuCfdsHs7XaE3oWAKKUQKWfVkWmcJpdeOpCB8/+QEEdCI+tAV29CMOKJBdIGPtEAGbMAGZ4BEhOAFAZl7rMCE8/hKT1EU5cgO9pgJDmlT6bgKBcAADECQKIGRHMcKoXiJIFkEGQBK5Lg8zSgKJcmP1bIJzVORK5kQ5OiQKrkZgQAAOw==" border="0" title="phpMyAdmin" /></a><br />Configuration Security Checker</div>';
echo '<ol>';


//START

// $cfg['blowfish_secret']

$blowfish_secret_isset = (isset($cfg['Servers'][$i]['auth_type']) && $cfg['Servers'][$i]['auth_type']== 'cookie' && !isset($cfg['blowfish_secret']))?show_message('$cfg[\'blowfish_secret\']',' should be set as a strong random passphrase because you use the "cookie" auth_type',$color_warning):'';

$blowfish_secret = isset($cfg['blowfish_secret'])?$cfg['blowfish_secret']:FALSE;
$is_digit_include = (preg_match("/\d/i", $blowfish_secret));
$is_char_include = (preg_match("/\S/i", $blowfish_secret));
$is_nonword_include = (preg_match("/\W/i", $blowfish_secret));
if($blowfish_secret!=FALSE)
{
	if(strlen($blowfish_secret) < 8)
	{
		show_message('$cfg[\'blowfish_secret\']',' should have enough length.',$color_warning);
	}
	else if ( (!$is_char_include) OR (!$is_digit_include) OR (!$is_nonword_include))
	{
	  show_message('$cfg[\'blowfish_secret\']',' should contain both alphanumerics and (special) characters.',$color_warning); 	
	}	
}

 //$cfg['Servers'][$i]['ssl']

$ssl_to_sqlserver_isset = (!isset($cfg['Servers'][$i]['ssl']))?show_message('$cfg[\'Servers\'][$i][\'ssl\']','should be enabled if your web server supports it.',$color_warning):'';

$ssl_to_sqlserver = (isset($cfg['Servers'][$i]['ssl']) && $cfg['Servers'][$i]['ssl']!=true)?show_message('$cfg[\'Servers\'][$i][\'ssl\']','should be set to true if your web server supports it.',$color_warning):'';


//$cfg['ForceSSL']

$force_ssl_isset = (!isset($cfg['ForceSSL']))?show_message('$cfg[\'ForceSSL\']','should be enabled if your web server supports it.',$color_warning):'';	

$force_ssl = (isset($cfg['ForceSSL']) && $cfg['ForceSSL'] !=true)?show_message('$cfg[\'ForceSSL\']','should be set to true if your web server supports it.',$color_warning):'';


// $cfg['Servers'][$i]['extension'] 

$extension =  (isset($cfg['Servers'][$i]['extension']) && $cfg['Servers'][$i]['extension'] == "mysql") ?show_message('$cfg[\'Servers\'][$i][\'extension\']',' should be set to mysqli for performance if your MySQL server version is 4.1 or newer.',$color_neutral):'';

$auth_type =  (isset($cfg['Servers'][$i]['auth_type']) && $cfg['Servers'][$i]['auth_type']== 'config' &&  isset($cfg['Servers'][$i]['user']) && $cfg['Servers'][$i]['user']!="" && isset($cfg['Servers'][$i]['password']) && $cfg['Servers'][$i]['password']!="")?show_message('$cfg[\'Servers\'][$i][\'auth_type\']= \'config\'','You set auth_type \'config\' and include username and password for auto-login, which is not a desirable option for live host. Any one who knows phpMyAdmin URL can directly access your phpMyAdmin panel. Set config_type to cookie or http. If you feel this is necessary, use additional protection settings - $cfg[\'Servers\'][$i][\'AllowDeny\'][\'order\'] and  $cfg[\'Servers\'][$i][\'AllowDeny\'][\'rules\']  and $cfg[\'TrustedProxies\']. However, IP-based protection may not be reliable if your IP belongs to an ISP where thousands of users,including you, are connected to.',$color_warning):'';

$AllowArbitraryServer  = (isset($cfg['AllowArbitraryServer']) && $cfg['AllowArbitraryServer'] != false) ?show_message('$cfg[\'AllowArbitraryServer\']',' should be disabled as this option allows attackers to bruteforce login to any MySQL servers on the Net. If you feel this is necessary, use additional protection settings - $cfg[\'Servers\'][$i][\'AllowDeny\'][\'order\'] and  $cfg[\'Servers\'][$i][\'AllowDeny\'][\'rules\'] and $cfg[\'TrustedProxies\']. However, IP-based protection may not be reliable if your IP belongs to an ISP where thousands of users,including you, are connected to.',$color_warning):'';

$LoginCookieValidity  = (isset($cfg['LoginCookieValidity']) && $cfg['LoginCookieValidity'] < 1800) ?show_message('$cfg[\'LoginCookieValidity\']',' should be best set to 1800. Larger than 1800 may pose a security risk such as impersonation.',$color_warning):'';

$SaveDir =  (isset($cfg['SaveDir'] )) ?show_message('$cfg[\'SaveDir\']',' should be double checked to ensure that it is not a world-accessible directory by all other users on your server.',$color_notice):'';

$TempDir =  (isset($cfg['TempDir'] )) ?show_message('$cfg[\'TempDir\']',' should be double checked to ensure that it is not a world-accessible directory by all other users on your server.',$color_notice):'';

//END 
echo '</ol>';  

if($no==0)
{
	?>
	<h3 style="color:#009900;text-align:center;">Congratulations! All settings are detected as secure!<br/>Please don't forget to check security whenever you create new configuration file.</h3>
	<?
}
?>



<div style="text-align:center;font-style:italic;font-size:90%;">
Contributed by<br/>
<a href="http://yehg.net/"target="_blank"><img border="0" title="YGN Ethical Hacker Group from Yangon, Myanmar" src='data:;base64,R0lGODlhggAvANUAAAAAAMPDwXt7ezo6OhUVE////7KysGBgX6GhoA0NDOPj4pmZmU9PTjMzM9bW1pmZmbq6uCkpKe/v72ZmZggICEpKSoqKiKqqqPf39x0dHBAQEFpaWt7e3kJCOrW1tczMzISEg3Nzc729va2trRkZGebm5lJSUu/v90JCQmZmZq2ttaWlpSEhIYyMjMXFxQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAHAP8ALAAAAACCAC8AAAb/wJLHQCwaj8ikcslEQkTQqHRKrVqv2CukNAotvuCweEwum8/iFouiabvf8Lh8Tq/PCZeLocDv+/+AgYKDhIANAIiJiouMjY6PkI8JI5SFlpeYhBIRkZ2en5+TlZmkpYWboKmqqaIjpq+wfairtLWMrbG5pbO2vbS4lx8BGH4KIhJ8GB8uzC4lBQrIfSUfxKS8iQQDDdwNAxok290DESQNCYoRGQARLIkU3gPyJIoUEeiICQ0EjcCWCwAW9MGAggSHAiIOKRK4AYW0AmoOXuO0aIO1PihCAHIxgYNCAAQ+tAAgAiCABiL+CFA0oUCIRA0kbOhHyRWmCgAc8LEAAEGB/w8JNAhYgaDoQQYAWu40uIuiogMSQmw4cGACiQgHTGwJcWDABAkfDQJ0AZDFwQVUqzol8QGaOwADCsy8VTOTAxIVCjgAwIDPBqaA5oLYmUFiJmyIDpTQ4MiCA34AoH7U8AFgAICDBzxqGaDASrgY5i7yd6lFAgQTNOgsQEJpCQWwkVXYEIKCzxaFmzI6oMAEGBCQAbS4m1jB1BATBEjgGaAFBRcGHpGQAAGAAQz0BoSmOSrTXIF8NFj4GUFDBg0mCszGwED1itwTd3MYzKfEW+HEIzuw8KzPyuYUOIDAIxqlJhAIoImmCGnBnOQHVgWUgMAXKDRQAAN9lRBBBBs0YP8YJohFpuGGDURAQSLD0ZNUCSiwUCIKCox0mXUBOEKCAgGMx4cC8GxHV3eYYMDCBn6AQMEefVhgIYbEOLBOA/0d5lQiijHWSIqIfPURAQ7ICFBLEzSinAkNHFCBABgIEIEEJnBn02Ea9CULCuyYYCcBS1ZgTQAUZKCAboscgIEHeVwAwUcLKKDiBBiEpQBAHwx4pF41QYACASVUp4gLDlRQAgcrUAJBmAAwaIkEGf0hwQQZsOBqBge4FMJFC6AQJYhTIlLBBxz0ygGLiYRgAGQmBOCUBgashMBnCVjg6692fkCnIih8IMAICvhaAoKl1lUKBhf5gYEE5EpADLi6FBD/YqkJtNvuiYhQAG8+i8gLgL0LussGPqNp4K6++Xib7sCDrOvLwZCYSvDC6uaK8MOOKMzwwAZDbHG3eUysccMXd1yvHhYEYIAHJJds8skop6zyyiyTLIIB5xAg88w012zzzTjnrDPOGRjA0QRABy300EQXbfTRSCet9NJMN100dCTYIfXUVNdBwQAQuBDA1lx37fXXYIct9thfi0TJvB5DPMBDG0+8Qqj8pv3w2m1v/PYIcct9MN11uw233mqz3ffAd+cNuC18D05w4Yg0YMK8FGwwZQImMgJPVUCXs4GVJ03AgldpTdBmA0J3xTkiiQPiwApgtEUWGCtU84cDFyww/4Jhq/+hgE8STAgGBIL3wTgAIHCgIgAZlEAqIi0UcMAiKHxYwAQVzJJXdeD18QEF9PkhkyKp9+HAR4gUyAgBHuyomSImIGOBBn8YkEEBLqDdbSDDF3988ssP8MwHnIsJB5ATtAi0jxMOEQFjDOCAoEklIBwYWgB4Eb4CGI8EIPBdC9rCABaIIQIEUAAGcBIC34UpVi2Anx/kV4AaTYB1C0DAAAIEiPwZLxEkUF4iViCBC6wqEQgIEVSuIoEAWKkkjECAB9DGAh2iLngWmBQgUJAeP4jgOSLoyR8QVBkV9oGFEKBASvrAgQRkT3h/I54DNgA756GuADz5gAPgFalGbP8ggsbgHAQWMIEvXGAmC7hiOn74RECQiQ8O+IAiD1IBPfkhjC5oQQTCpRcAEIUA8ZvfFSHgBw5ooHl/yJ8DBOCrPz2PAiMYYQMu4BJE7KcRJuAAJ5GSiD0mKhoIWgAEDNjIA3yAgsFjQFwccJ81baACDigZAlgQQgFYaHY9QQAmVzg/CCTAAy4YwRA005ZQprF4LCABCfTxQxRAZAXaOxEU7AeADSggAuicFgAggAA2yOxECEhWMWhZyD+EgAV8gA4EBJABmWxAAPOKgAsKsAAu/aFGHkCABtj2ngJAgAUIcMok8PfNGyLiRmHywDsdh4LxnBADIUiAvOy1AQm4IyX/OJnnBZK4S2HOygBoq2AWlcIHD+TwmA6AQADCJABEUgAF4AIXBwaQPKCEwFwYUAA3LHrNDxABeILIXwmO18SuQEQRBODAYyxpwQAo8gMYAsu9PICBNqGzGQLqSf2CxVDwBc8zACABCubRxIZcJEzgAYg25CGv9LmRAHtFBys9AADDFmJ4bOQcAWo1AQQcT1cB0AwFJmAAEUBAqBVoAALWUaoYbtYFn80aQA7wmWB54CMV5MMFGICC2qKAUS0AwUVWZYL+BGADA6itLweCANretjM/2cBqHpvGR7AzXs91bnQdgS+43PVblGzb8A7ni9gqDhbb5S7irvtdU4RXvLTwS255S3Fe9KpCvevNxAhWcAEC/Ou++M2vfvfL3/7aowULaIGAB0zgAhv4wAhOsIINzMcRZCq1EI6whCdM4Qpb2MJNyLCGN7xhD5QgCAA7'/></a>
</div>
</body>
</html>


